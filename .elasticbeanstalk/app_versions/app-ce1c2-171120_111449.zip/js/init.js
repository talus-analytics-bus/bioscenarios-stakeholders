(() => {
	App.initialize();
	Routing.precompileTemplates();
	Routing.initializeRoutes();
})();
