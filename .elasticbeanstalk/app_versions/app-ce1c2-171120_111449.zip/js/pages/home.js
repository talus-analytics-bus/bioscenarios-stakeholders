(() => {
	App.initHome = () => {

	};
})();
